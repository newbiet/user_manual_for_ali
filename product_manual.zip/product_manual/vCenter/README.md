# 10 vCenter管理（技术预览）

VMware vCenter Server 是VMware vCenter的集中式管理平台。

针对用户已经部署VMware vCenter Server的应用场景，从系统 1.8 版本起，系统可以通过VMware提供的公开API接口，良好地兼容和管理VMware vCenter Server虚拟化管理平台部分功能，实现多虚拟化平台的统一管理。

支持对现有数据中心中的VMware虚拟化环境进行管理，能够查看VMware vCenter Server所管理的vSphere服务器资源和虚拟机资源，能够在虚拟数据中心中使用VMware vSphere资源，并在VMware vCenter集群中完成对云主机的常用操作。


